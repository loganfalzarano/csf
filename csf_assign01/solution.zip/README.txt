Names: Logan Falzarano, Tal Magdish

We wrote all of the functionality for MS1 together. Work was shared evenly.